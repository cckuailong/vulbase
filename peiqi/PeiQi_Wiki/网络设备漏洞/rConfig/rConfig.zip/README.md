# rConfig类似-

#### rConfig useradmin.inc.php 信息泄露漏洞

#### rConfig userprocess.php 任意用户创建漏洞

#### rConfig ajaxArchiveFiles.php 后台远程命令执行漏洞

#### rConfig ajaxEditTemplate.php 后台远程命令执行漏洞







